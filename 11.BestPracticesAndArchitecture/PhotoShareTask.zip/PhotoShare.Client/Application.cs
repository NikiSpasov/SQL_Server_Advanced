﻿namespace PhotoShare.Client
{
    using Core;

    public class Application
    {
        public static void Main()
        { 
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
