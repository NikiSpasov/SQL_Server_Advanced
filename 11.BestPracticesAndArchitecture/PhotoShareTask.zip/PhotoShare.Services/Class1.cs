﻿using System;

namespace PhotoShare.Services
{
    public class Class1
    {
    }
}
