﻿namespace PhotoShare.Data
{
    internal class ServerConfig
    {
        internal static string ConnectionString => @"Server=Niki\SQLExpress;Database=PhotoShare;Integrated Security=True;";
    }
}
