namespace Stations.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=Niki\SQLExpress;Database=StationsExercice;Trusted_Connection=True";
	}
}