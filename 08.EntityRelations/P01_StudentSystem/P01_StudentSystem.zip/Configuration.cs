﻿namespace P01_StudentSystem
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=Niki\SQLExpress; Database=StudentSystem; Integrated security=True";
    }
}
