﻿namespace P01_StudentSystem.Data.Models
{
    public class HomeworkSubmission
    {
        public int Id { get; set; }

        public int StudentId { get; set; }
        public Student Student { get; set; }

        public int HomeworkId { get; set; }
        public Homework Homework { get; set; }

        public HomeworkSubmission(Student student, Homework homework)
        {
            this.Student = student;
            this.Homework = homework;
        }

        public void SumbitHomework()
        {
            this.Student.Homeworks.Add(this.Homework);
        }
    }
}
