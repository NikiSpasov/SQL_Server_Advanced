﻿namespace P03_FootballBetting.Data.Models
{
    public enum Result
    {
        Win,
        Lose,
        Draw
    }
}