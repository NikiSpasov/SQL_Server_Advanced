﻿namespace P03_FootballBetting.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=Niki\SQLExpress; Database=FootballBetting; Integrated security=True";
    }
}
