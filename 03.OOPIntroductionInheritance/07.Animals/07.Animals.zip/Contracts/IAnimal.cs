﻿public interface IAnimal
{
    string Name { get; }
    int Age { get; }
    string Gender { get; }
}
