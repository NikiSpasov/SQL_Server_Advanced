﻿public interface ISoundProducable
{
     string ProduceSound();
}

