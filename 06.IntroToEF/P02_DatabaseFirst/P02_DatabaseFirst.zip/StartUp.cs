﻿namespace P02_DatabaseFirst
{
    public class Program
    {
        public static void Main()
        {


            // Scaffold-DbContext -Connection "Server=Niki\SqlExpress;Database=SoftUni;Integrated Security=True" -Provider Microsoft.EntityFrameworkCore.SqlServer -OutputDir Data/Models 
        }
    }
}
