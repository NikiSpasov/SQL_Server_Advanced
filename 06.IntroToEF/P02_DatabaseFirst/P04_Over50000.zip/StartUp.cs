﻿namespace P02_DatabaseFirst
{
    using System;
    using System.Linq;
    using P02_DatabaseFirst.Data;

    public class StartUp
    {
        public static void Main()
        {
            //salary over 50 000:
            var db = new SoftUniContext();
            using (db)
            {
                var allEmpl = db.Employees.ToList();

                foreach (var empl in allEmpl
                    .Where(e => e.Salary > 50000)
                    .OrderBy(x => x.FirstName)
                    .Select(x => x.FirstName))
                    {
                    Console.WriteLine(empl);
                    }
            }
            // Scaffold-DbContext -Connection "Server=Niki\SqlExpress;Database=SoftUni;Integrated Security=True" -Provider Microsoft.EntityFrameworkCore.SqlServer -OutputDir Data/Models 
        }
    }
}
