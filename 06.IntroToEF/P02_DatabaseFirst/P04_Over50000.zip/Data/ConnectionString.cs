﻿public class ConnectionString
{
    public const string Connection = @"Server=Niki\SqlExpress;Database=SoftUni;Integrated Security = True";
}

