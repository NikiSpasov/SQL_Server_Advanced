﻿namespace P02_DatabaseFirst
{
    using System;
    using System.Linq;
    using P02_DatabaseFirst.Data;

    public class StartUp
    {
        public static void Main()
        {
            //employyes full info:
            var db = new SoftUniContext();

            var allEmpl = db.Employees.ToList();

            foreach (var empl in allEmpl)
            {
                Console.WriteLine($"{empl.FirstName} {empl.LastName} {empl.MiddleName}" +
                                  $"{empl.Department} {empl.JobTitle} {empl.Salary:f2}");
            }

            // Scaffold-DbContext -Connection "Server=Niki\SqlExpress;Database=SoftUni;Integrated Security=True" -Provider Microsoft.EntityFrameworkCore.SqlServer -OutputDir Data/Models 
        }
    }
}
