﻿namespace P02_DatabaseFirst
{
    using System;
    using System.Linq;
    using System.Security.Cryptography.X509Certificates;
    using P02_DatabaseFirst.Data;

    public class StartUp
    {
        public static void Main()
        {
            //Employees from Research and Development:
            
            var db = new SoftUniContext();
            using (db)
            {
                var seslectedEmployees = db.Employees
                    .Where(e => e.Department.Name == "Research and Development")
                    .OrderBy(e => e.Salary)
                    .ThenByDescending(e => e.FirstName)
                    .Select(x => new {x.FirstName, x.LastName, x.Department, x.Salary });

                foreach (var empl in seslectedEmployees)
          
                    {
                    Console.WriteLine($"{empl.FirstName} {empl.LastName} from {empl.Department.Name} - ${empl.Salary:f2}");
                    }
            }
            // Scaffold-DbContext -Connection "Server=Niki\SqlExpress;Database=SoftUni;Integrated Security=True" -Provider Microsoft.EntityFrameworkCore.SqlServer -OutputDir Data/Models 
        }
    }
}
