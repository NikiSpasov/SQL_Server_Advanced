﻿namespace P02_DatabaseFirst
{
    using System;
    using System.Linq;
    using System.Security.Cryptography.X509Certificates;
    using P02_DatabaseFirst.Data;
    using P02_DatabaseFirst.Data.Models;

    public class StartUp
    {
        public static void Main()
        {
            //6.Adding a New Address and Updating Employee:


            using (var db = new SoftUniContext())
            {
                var address = new Address
                {
                    AddressText = "Vitoshka 15",
                    TownId = 4
                };

                var employeeNakov = db.Employees.SingleOrDefault(x => x.LastName == "Nakov");
                employeeNakov.Address = address;
                db.SaveChanges();

                var seslectedEmployees = db.Employees
                    .OrderByDescending(e => e.AddressId)
                    .Take(10)
                    .Select(e => e.Address.AddressText);

                foreach (var empl in seslectedEmployees)

                {
                    Console.WriteLine($"{empl}");
                }
            }
            // Scaffold-DbContext -Connection "Server=Niki\SqlExpress;Database=SoftUni;Integrated Security=True" -Provider Microsoft.EntityFrameworkCore.SqlServer -OutputDir Data/Models 
        }
    }
}
