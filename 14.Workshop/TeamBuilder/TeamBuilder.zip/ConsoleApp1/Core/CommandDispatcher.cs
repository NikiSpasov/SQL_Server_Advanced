﻿namespace TeamBuilder.App.Core
{
    public class CommandDispatcher
    {
        public string Dispatch()
        {
            return "";
        }
    }
}
