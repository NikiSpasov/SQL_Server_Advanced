﻿namespace Employees.App
{
    public class Configuration
    {
        public static string ConnectionString => "Server=Niki\\SQLExpress;Database=EmployeesAMO;Integrated Security=True;";
    }
}
