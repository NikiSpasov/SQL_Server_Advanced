﻿namespace Employees.Data
{
    public class Configuration
    {
        public static string ConnectionString => "Server=Niki\\SQLExpress;Database=Employees;Integrated Security=True;";
    }
}
