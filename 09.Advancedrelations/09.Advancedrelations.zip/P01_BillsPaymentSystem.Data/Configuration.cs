﻿namespace P01_BillsPaymentSystem.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=NikiThinkPad\SQLExpress; Database=BillsPaymentSystem; Integrated security=True";
    }
}
