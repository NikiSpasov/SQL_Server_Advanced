﻿namespace P01_BillsPaymentSystem.Data.Models
{
    public enum PaymenthMethodType
    {
        BankAccount,
        CreditCard
    }
}

