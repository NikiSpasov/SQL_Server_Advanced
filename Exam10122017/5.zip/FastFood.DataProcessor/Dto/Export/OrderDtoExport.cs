﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FastFood.DataProcessor.Dto.Export
{
    using System.Linq;

    public class OrderDtoExport
    {
        public string Customer { get; set; }

        public ICollection<ItemDtoEx> Items { get; set; } = new List<ItemDtoEx>();

        public decimal TotalPrice => this.Items.Sum(i => i.Price);
    }
}
