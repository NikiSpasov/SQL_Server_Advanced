﻿using System;
using System.IO;
using FastFood.Data;

namespace FastFood.DataProcessor
{
    using System.Linq;
    using FastFood.DataProcessor.Dto.Export;
    using Newtonsoft.Json;

    public class Serializer
	{
		public static string ExportOrdersByEmployee(FastFoodDbContext context, string employeeName, string orderType)
		{
		    var orderT = Enum.Parse<Models.Enums.Type>(orderType);

		    var orders = context.Orders
		        .Where(o => o.Employee.Name == employeeName && o.Type == orderT)
                .ToArray()
                .Select(o => new OrderDtoExport
		        {
		            Customer = o.Customer,
                    Items = o.OrderItems.Select(i => new ItemDtoEx
                    {
                        Name = i.Item.Name,
                        Price = i.Item.Price,
                        Quantity = i.Quantity
                    }).ToArray(),
		        })
                .OrderByDescending(o => o.TotalPrice)
                .ThenByDescending(o => o.Items.Count())
                .ToArray();

		    var json = JsonConvert.SerializeObject(orders);

		    return json;
		}

		public static string ExportCategoryStatistics(FastFoodDbContext context, string categoriesString)
		{
			throw new NotImplementedException();
		}
	}
}