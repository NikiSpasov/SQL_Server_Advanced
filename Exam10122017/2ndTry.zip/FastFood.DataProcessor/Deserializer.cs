﻿using System;
using FastFood.Data;
namespace FastFood.DataProcessor
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Text;
    using AutoMapper;
    using FastFood.DataProcessor.Dto.Import;
    using FastFood.Models;
    using Newtonsoft.Json;
    using ValidationContext = System.ComponentModel.DataAnnotations.ValidationContext;

    public static class Deserializer
	{
		private const string FailureMessage = "Invalid data format.";
		private const string SuccessMessage = "Record {0} successfully imported.";

		public static string ImportEmployees(FastFoodDbContext context, string jsonString)
		{
			var sb = new StringBuilder();

		    var deserializedEmployees = JsonConvert.DeserializeObject<EmployeeDto[]>(jsonString);

            var validEmployees = new List<Employee>();

		    var validPossitions = new List<Position>();

		    Position position = null;

		    foreach (var employeeDto in deserializedEmployees)
		    {
		        if (!IsValid(employeeDto))
		        {
		            sb.AppendLine(FailureMessage);
                    continue;
		        }

		        try
		        {		       
		            if (validPossitions.Any(p => p.Name == employeeDto.Position))
		            {
		                continue;
		            }

		            position = new Position()
		            {
		                Name = employeeDto.Position
		            };

                    validPossitions.Add(position);

                }
                catch (Exception e)
		        {
		            sb.AppendLine(FailureMessage);
		            continue;
                }

		        var validEmployee = new Employee()
		        {
		            Name = employeeDto.Name,
                    Age = employeeDto.Age,
                    Position = position
		        }; //Mapper.Map<Employee>(employeeDto);

                validEmployees.Add(validEmployee);

		        sb.AppendLine(string.Format(SuccessMessage, employeeDto.Name));
		    }
		    context.Positions.AddRange(validPossitions);
            context.Employees.AddRange(validEmployees);
		    context.SaveChanges();

		    var result = sb.ToString();
		    return result;
		}

		public static string ImportItems(FastFoodDbContext context, string jsonString)
		{
			throw new NotImplementedException();
		}

		public static string ImportOrders(FastFoodDbContext context, string xmlString)
		{
			throw new NotImplementedException();
		}

	    private static bool IsValid(object obj)
	    {
	        var validationContext = new ValidationContext(obj);
	        var validationResults = new List<ValidationResult>();

	        var isValid = Validator.TryValidateObject(obj, validationContext, validationResults, true);

	        return isValid;
	    }
    }
}