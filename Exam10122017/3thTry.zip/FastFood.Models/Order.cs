﻿namespace FastFood.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using Type = Enums.Type;

    public class Order
    {
        public int Id { get; set; }

        [Required]
        public string Customer { get; set; }

        [Required]
        public DateTime DateTime { get; set; }

        public int EmployeeId { get; set; }

        [Required]
        public Employee Employee { get; set; }

        public Type Type { get; set; } = Type.ForHere;

        [Required]
        [NotMapped]
        public decimal TotalPrice { get; set; } //may be getter only?

        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

    }
}
