﻿namespace FastFood.DataProcessor.Dto.Import
{
    using System.ComponentModel.DataAnnotations;

    public class EmployeeDto
    {
        [MinLength(3), MaxLength(30), Required]
        public string Name { get; set; }

        [Range(15, 80)]
        public int Age { get; set; }

        public string Position { get; set; }
    }
}