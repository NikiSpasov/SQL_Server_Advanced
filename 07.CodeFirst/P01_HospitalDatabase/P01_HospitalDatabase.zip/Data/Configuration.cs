﻿namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server=Niki\SQLExpress;Database=Hospital;Integrated security=True";
    }
}
