﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=Niki\SQLExpress; Database=SalesDatabase; Integrated security=True";
    }
}
