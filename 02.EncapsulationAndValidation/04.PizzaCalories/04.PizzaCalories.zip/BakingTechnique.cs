﻿internal class BakingTechnique
{
}